export { default } from "./DashboardAnalysisLoading";
